from gym import fight_gym_trainer
from wild_pokemon import explore_location
from map_position import current_location

map_layout = [
    ["Pallet Town", "Viridian Forest", "Celadon City"],
    ["Victory Road", "Lavender Town", "Rock Tunnel"],
    ["Cerulean City", "Seafoam Islands", "Mt. Moon"]
]

player_position = [0, 0]  

def display_map():
    print("\nMap:")
    for i, row in enumerate(map_layout):
        row_display = []
        for j, location in enumerate(row):
            if [i, j] == player_position:
                row_display.append(f"[{location}]")  
            else:
                row_display.append(location)
        print(" | ".join(row_display))

def move_player(direction):
    global player_position
    i, j = player_position

    if direction == "up" and i > 0:
        player_position[0] -= 1
    elif direction == "down" and i < len(map_layout) - 1:
        player_position[0] += 1
    elif direction == "left" and j > 0:
        player_position[1] -= 1
    elif direction == "right" and j < len(map_layout[0]) - 1:
        player_position[1] += 1
    else:
        print("You can't move in that direction.")

def explore_map():
    while True:
        display_map()
        current_location = map_layout[player_position[0]][player_position[1]]
        print(f"\nYou are now in {current_location}.")
        if current_location in ["Pallet Town", "Celadon City", "Lavender Town", "Cerulean City"]:
            action = input("Do you want to fight the gym trainer, move, or quit? (gym/move/quit): ").strip().lower()
            if action == "gym":
                fight_gym_trainer(current_location)
            elif action == "move":
                direction = input("Which direction do you want to move? (up/down/left/right): ").strip().lower()
                move_player(direction)
            elif action == "quit":
                break
            else:
                print("Invalid input. Try again.")
        else:
            action = input("Do you want to explore, fight, capture Pokémon, move, or quit? (explore/fight/capture/move/quit): ").strip().lower()
            if action in ["explore", "fight", "capture"]:
                explore_location(current_location, action)
            elif action == "move":
                direction = input("Which direction do you want to move? (up/down/left/right): ").strip().lower()
                move_player(direction)
            elif action == "quit":
                break
            else:
                print("Invalid input. Try again.")

def get_current_location():
    """Return the current location of the player."""
    return map_layout[player_position[0]][player_position[1]]