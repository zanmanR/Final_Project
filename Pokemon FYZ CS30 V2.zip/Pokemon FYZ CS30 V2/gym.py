import random
from pokemon_list import pokemon_data
from battle import battle_logic

def fight_gym_trainer(location):
    print(f"\nYou are fighting the gym trainer at {location}! Prepare for battle!")

    gym_pokemon = random.choice(list(pokemon_data.keys()))
    print(f"The gym trainer sends out {gym_pokemon}!")

    battle_logic(gym_pokemon, "gym")