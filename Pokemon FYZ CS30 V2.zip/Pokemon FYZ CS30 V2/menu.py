from pokedex import view_pokedex
from battle import battle_logic, gym_badges
from map import explore_map
from add_pokemon import player_pokemon_list

def view_player_pokemon():
    print("\nYour Pokémon:")
    if not player_pokemon_list:
        print("You have no Pokémon yet! Go capture some!")
    else:
        for i, pokemon_entry in enumerate(player_pokemon_list, 1):
            name = pokemon_entry['name'].capitalize()
            xp = pokemon_entry['xp']
            print(f"{i}. {name} (XP: {xp})")

def view_gym_badges():
    print("\nGym Badges:")
    if not gym_badges:
        print("You don't have any gym badges yet!")
    else:
        for badge in gym_badges:
            print(f"- {badge}")

def display_menu():
    while True:
        print("\nMenu:")
        print("1. View Pokédex")
        print("2. View Your Pokémon")
        print("3. Explore Map")
        print("4. View Gym Badges")
        print("5. Quit Menu")
        choice = input("Choose an option (1/2/3/4/5): ").strip()

        if choice == "1":
            view_pokedex()
        elif choice == "2":
            view_player_pokemon()
        elif choice == "3":
            explore_map()
        elif choice == "4":
            view_gym_badges()
        elif choice == "5":
            break
        else:
            print("Invalid choice. Try again.")