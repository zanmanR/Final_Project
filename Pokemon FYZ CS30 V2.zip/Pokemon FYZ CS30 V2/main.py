from game_logic import choose_starter, tutorial
from map import explore_map
from menu import display_menu

def main():
    print("Welcome to the Pokémon FYZ!")
    
    action = input("New Game or Load Game? (new/load): *LOAD DOESNT WORK YET pick new* ").strip().lower()
    if action == "new":
        starter = choose_starter()
        tutorial(starter)
    elif action == "load":
        print("Loading saved game... (Feature not implemented yet)")
    else:
        print("Invalid choice. Exiting.")
        return

    while True:
        choice = input("Would you like to open the menu or quit? (menu/quit)").strip().lower()
        if choice == "menu":
            display_menu()
        elif choice == "quit":
            print("Thanks for playing!")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()