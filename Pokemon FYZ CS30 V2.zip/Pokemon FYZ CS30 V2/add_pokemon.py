from pokemon_list import pokemon_data

player_pokemon_list = []  

def add_to_pokemon_list(pokemon):
    """Add a Pokémon to the player's list with initial XP."""
    for p in player_pokemon_list:
        if p['name'] == pokemon:
            print(f"{pokemon} is already in your Pokémon list!")
            return
    player_pokemon_list.append({'name': pokemon, 'xp': 0})
    print(f"{pokemon} was added to your Pokémon list!")

def update_pokemon_xp(pokemon, xp):
    """Update XP for a Pokémon and check for evolution."""
    for p in player_pokemon_list:
        if p['name'] == pokemon:
            p['xp'] += xp
            print(f"{pokemon} gained {xp} XP! Total XP: {p['xp']}")
            check_evolution(p)
            return
    print(f"{pokemon} is not in your Pokémon list.")

def check_evolution(pokemon_entry):
    """Check if a Pokémon should evolve based on XP."""
    pokemon_name = pokemon_entry['name']
    current_xp = pokemon_entry['xp']

    if current_xp >= 20:  
        evolution = pokemon_data.get(pokemon_name, {}).get('Evolution')
        if evolution:
            print(f"{pokemon_name} is evolving into {evolution}!")
            pokemon_entry['name'] = evolution  
            pokemon_entry['xp'] = 0  
        else:
            print(f"{pokemon_name} cannot evolve further.")
