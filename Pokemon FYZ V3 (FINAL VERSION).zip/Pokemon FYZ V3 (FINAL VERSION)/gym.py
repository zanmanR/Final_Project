import random
from pokemon_list import pokemon_data
from battle import battle_logic
from player_database import player_data

# Data for each gym, including badge and available Pokémon
gym_data = {
    "Pallet Town": {
        "badge": "Pallet Badge",
        "pokemon": ["charizard", "venusaur", "blastoise"]
    },
    "Celadon City": {
        "badge": "Rainbow Badge",
        "pokemon": ["rhydon", "wigglytuff", "victreebel"]
    },
    "Lavender Town": {
        "badge": "Spirit Badge",
        "pokemon": ["mew", "mewtwo", "gengar"]
    },
    "Cerulean City": {
        "badge": "Cascade Badge",
        "pokemon": ["gyarados", "wartortle", "articuno"]
    }
}

def fight_gym_trainer(location):
    """
    Initiates a battle with a gym trainer based on the current location.
    
    Parameters:
    location (str): The name of the location where the gym is located.
    """
    # Check if the location has a gym
    if location not in gym_data:
        print(f"There is no gym at {location}.")
        return

    # Retrieve gym details: badge and available Pokémon for the gym
    gym = gym_data[location]
    badge = gym["badge"]
    pokemon_list = gym["pokemon"]

    # Check if the player already has the badge
    if badge in player_data["gym_badges"]:
        print(f"You have already defeated the gym at {location} and earned the {badge}.")
        return

    # Prepare for the battle by selecting the gym's Pokémon
    print(f"\nYou are challenging the gym trainer at {location}! Prepare for battle!")

    # Select a random Pokémon from the gym's available list
    gym_pokemon = random.choice(pokemon_list)
    print(f"The gym trainer sends out {gym_pokemon.capitalize()}!")

    # Start the battle using the `battle_logic` function
    battle_logic(gym_pokemon, "gym", location)
