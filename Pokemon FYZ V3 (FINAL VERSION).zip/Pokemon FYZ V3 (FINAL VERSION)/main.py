from game_logic import choose_starter, tutorial
from map import explore_map
from menu import display_menu
from player_database import player_data, save_player_data, load_player_data

def main():
    """
    Main function that runs the Pokémon Text Adventure Game.
    It allows the player to start a new game, load a saved game, and interact with the game.
    """
    print("Welcome to the Pokémon Text Adventure Game!")

    # Intro and game start
    action = input("New Game or Load Game? (new/load): ").strip().lower()
    
    # Handle new game
    if action == "new":
        name = input("What's your name, Trainer? ").strip()  # Ask for player's name
        player_data["name"] = name  # Save name to player database
        print(f"Welcome, {name}! Let's begin your Pokémon adventure!")

        # Choose starter Pokémon
        starter = choose_starter()
        # Add the starter to the player's Pokémon list
        player_data["pokemon_list"].append({"name": starter, "xp": 0})
        print(f"{starter.capitalize()} has been added to your Pokémon team!")

        # Start the tutorial
        tutorial(starter)
        save_player_data()  # Save player data after starting the new game

    # Handle loading an existing game
    elif action == "load":
        print("Loading saved game...")
        load_player_data()  # Load player data from the saved file
        print(f"Welcome back, {player_data['name']}!")

    # Handle invalid input
    else:
        print("Invalid choice. Exiting.")
        return

    # Main game loop
    while True:
        choice = input("Would you like to open the menu or quit? (menu/quit): ").strip().lower()
        
        if choice == "menu":
            display_menu()  # Open the menu
        elif choice == "quit":
            print("Thanks for playing!")
            save_player_data()  # Save player data before exiting
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
