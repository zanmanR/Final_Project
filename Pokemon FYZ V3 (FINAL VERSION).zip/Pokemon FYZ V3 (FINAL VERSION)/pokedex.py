from pokemon_list import pokemon_data

def view_pokedex():
    """
    Display the Pokédex with each Pokémon's name, HP, and moves.
    
    Iterates through the `pokemon_data` dictionary and prints out each Pokémon's
    name, HP, and the list of moves they can learn.
    """
    print("\nPokédex:")
    
    # Loop through each Pokémon in the pokemon_data
    for name, details in pokemon_data.items():
        # Display Pokémon name, HP, and its moves
        print(f"{name}: HP={details['HP']}, Moves={', '.join(details['Moves'])}")
