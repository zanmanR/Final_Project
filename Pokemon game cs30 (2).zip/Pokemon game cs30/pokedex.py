from pokemon_list import pokemon_data

def view_pokedex():
    print("\nPokédex:")
    for name, details in pokemon_data.items():
        print(f"{name}: HP={details['HP']}, Moves={', '.join(details['Moves'])}")