import random
from pokemon_list import pokemon_data
from battle import battle_logic
from add_pokemon import add_to_pokemon_list 

def explore_location(location, action):
    if action == "explore":
        print(f"\nYou explore the area around {location}.")
        event = random.choice(["item", "wild_pokemon", "nothing"])
        if event == "item":
            item = random.choice(["Potion", "Poké Ball", "Revive"])
            print(f"You found a {item}!")
            # Logic for adding items to inventory js do that later
        elif event == "wild_pokemon":
            wild_pokemon = random.choice(list(pokemon_data.keys()))
            print(f"While exploring, you encountered a wild {wild_pokemon}!")
            battle_logic(wild_pokemon, "wild")
        else:
            print("You found nothing of interest.")
    
    elif action == "fight":
        wild_pokemon = random.choice(list(pokemon_data.keys()))
        print(f"\nA wild {wild_pokemon} appears! Prepare for battle!")
        battle_logic(wild_pokemon, "wild")
