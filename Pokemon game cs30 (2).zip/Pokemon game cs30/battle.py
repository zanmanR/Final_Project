from pokemon_list import pokemon_data
import random
from add_pokemon import add_to_pokemon_list, player_pokemon_list, update_pokemon_xp
from map_position import current_location

gym_badges = [] 

def choose_move(pokemon):
    print(f"Choose a move for {pokemon}:")
    for i, move in enumerate(pokemon_data[pokemon]["Moves"], 1):
        print(f"{i}. {move}")
    choice = int(input("Enter the number of the move: ")) - 1
    move = pokemon_data[pokemon]["Moves"][choice]
    move_name, damage = move.split(" (")
    damage = int(damage[:-1])
    return move_name, damage

def battle_logic(opponent_pokemon, battle_type, gym_name=current_location):
    global gym_badges

    if not player_pokemon_list:
        print("You have no Pokémon to battle with! Catch some Pokémon first.")
        return

    print("Choose your Pokémon for battle:")
    for i, owned_pokemon in enumerate(player_pokemon_list, 1):
        print(f"{i}. {owned_pokemon['name']}")
    while True:
        choice = input("Enter the number of your Pokémon: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(player_pokemon_list):
            player_pokemon = player_pokemon_list[int(choice) - 1]['name']
            break
        else:
            print("Invalid choice. Try again.")

    player_hp = pokemon_data[player_pokemon]["HP"]
    opponent_hp = pokemon_data[opponent_pokemon]["HP"]

    while player_hp > 0 and opponent_hp > 0:
        print(f"\n{player_pokemon}: {player_hp} HP")
        print(f"{opponent_pokemon}: {opponent_hp} HP")

        move_name, damage = choose_move(player_pokemon)
        print(f"{player_pokemon} used {move_name}! It dealt {damage} damage!")
        opponent_hp -= damage

        if opponent_hp <= 0:
            print(f"{opponent_pokemon} fainted! You win the {battle_type} battle!")
            update_pokemon_xp(player_pokemon, 5)  
            if battle_type == "gym":
                badge_name = f"{gym_name} Badge"
                if badge_name not in gym_badges:
                    gym_badges.append(badge_name)
                    print(f"Congratulations! You earned the {badge_name}!")
            elif battle_type == "wild":
                catch_choice = input(f"Do you want to catch {opponent_pokemon}? (yes/no): ").strip().lower()
                if catch_choice == "yes":
                    add_to_pokemon_list(opponent_pokemon)
            break

        opp_move = random.choice(pokemon_data[opponent_pokemon]["Moves"])
        opp_move_name, opp_damage = opp_move.split(" (")
        opp_damage = int(opp_damage[:-1])
        print(f"{opponent_pokemon} used {opp_move_name}! It dealt {opp_damage} damage!")
        player_hp -= opp_damage

        if player_hp <= 0:
            print(f"{player_pokemon} fainted! You lose the {battle_type} battle!")
            update_pokemon_xp(player_pokemon, 2)  
            break