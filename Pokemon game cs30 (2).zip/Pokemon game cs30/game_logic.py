from pokemon_list import pokemon_data
from add_pokemon import add_to_pokemon_list  

def choose_starter():
    print("Choose your starter Pokémon:")
    starters = ["bulbasaur", "charmander", "squirtle"]  
    for i, starter in enumerate(starters, 1):
        print(f"{i}. {starter.capitalize()}")  

    while True:
        choice = input("Enter the number of your choice: ").strip()
        if choice in ["1", "2", "3"]:
            starter = starters[int(choice) - 1]
            print(f"You chose {starter.capitalize()}!")
            add_to_pokemon_list(starter)  
            return starter
        else:
            print("Invalid choice. Try again.")

def tutorial(starter):
    print(f"\nWelcome to the world of Pokémon! You start your journey with {starter.capitalize()}.")
    print("Explore the map, battle wild Pokémon, and become a Pokémon Master!")
