import random
from pokemon_list import pokemon_data
from battle import battle_logic
from add_pokemon import add_to_pokemon_list

# Define Pokémon spawns for each location
location_pokemon_spawns = {
    "Viridian Forest": [
        "bulbasaur", "oddish", "bellsprout", "tangela", "charmander", "vulpix", 
        "growlithe", "flareon", "moltres", "rattata", "raticate", "pidgey"
    ],
    "Victory Road": [
        "machop", "geodude", "meowth", "jigglypuff", "farfetch'd", "eevee", 
        "caterpie", "weedle", "venonat", "pinsir", "doduo", "fearow", "articuno"
    ],
    "Rock Tunnel": [
        "zubat", "geodude", "pikachu", "jolteon", "magnemite", "electrode", "zapdos", 
        "vaporeon", "flareon", "porygon", "chansey", "ditto", "snorlax", "ekans", 
        "nidoran♀", "nidorina", "nidoqueen", "nidoran♂", "nidorino", "nidoking", "koffing", 
        "weezing", "onix"
    ],
    "Seafoam Islands": [
        "squirtle", "poliwag", "shellder", "lapras", "magikarp", "omanyte", "tentacool", 
        "seel", "dewgong", "horsea"
    ],
    "Mt. Moon": [
        "clefairy", "zubat", "machop", "primeape", "clefairy", "togepi", "gastly", "mimikyu", 
        "steelix", "dratini", "salamence", "abra", "mewtwo", "mew", "exeggutor"
    ],
}

def explore_location(location, action):
    """
    Handles exploration and wild Pokémon encounters based on location.
    
    Args:
        location (str): The location the player is exploring.
        action (str): The action to perform ("explore" or "fight").
    """
    if action == "explore":
        # Exploring the current location
        print(f"\nYou explore the area around {location}.")
        
        # Random exploration event
        event = random.choice(["item", "wild_pokemon", "nothing"])
        
        if event == "item":
            # The player finds an item
            item = random.choice(["Potion", "Poké Ball", "Revive"])
            print(f"You found a {item}!")
            # Item logic can be added here later
            
        elif event == "wild_pokemon":
            # Wild Pokémon encounter
            if location in location_pokemon_spawns:
                # Spawn a location-specific Pokémon
                wild_pokemon = random.choice(location_pokemon_spawns[location])
                print(f"While exploring, you encountered a wild {wild_pokemon.capitalize()}!")
                battle_logic(wild_pokemon, "wild")
            else:
                print("There are no wild Pokémon in this area.")
                
        else:
            # Nothing of interest found
            print("You found nothing of interest.")
    
    elif action == "fight":
        # Fighting a wild Pokémon in the location
        if location in location_pokemon_spawns:
            # Spawn a location-specific Pokémon
            wild_pokemon = random.choice(location_pokemon_spawns[location])
            print(f"\nA wild {wild_pokemon.capitalize()} appears! Prepare for battle!")
            battle_logic(wild_pokemon, "wild")
        else:
            print("There are no wild Pokémon to fight in this area.")
