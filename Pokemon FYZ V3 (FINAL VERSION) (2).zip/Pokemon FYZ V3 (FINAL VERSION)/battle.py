from pokemon_list import pokemon_data
import random
from player_database import player_data, save_player_data
from map_position import current_location
from add_pokemon import update_pokemon_xp


def choose_move(pokemon):
    """
    Let the player choose a move for their Pokémon.
    Displays the available moves and returns the chosen move and its damage.
    """
    print(f"Choose a move for {pokemon}:")
    for i, move in enumerate(pokemon_data[pokemon]["Moves"], 1):
        print(f"{i}. {move}")
    
    while True:
        try:
            # Get the player's choice and ensure it's a valid move
            choice = int(input("Enter the number of the move: ")) - 1
            if 0 <= choice < len(pokemon_data[pokemon]["Moves"]):
                move = pokemon_data[pokemon]["Moves"][choice]
                move_name, damage = move.split(" (")
                damage = int(damage[:-1])  # Extract and convert damage to integer
                return move_name, damage
            else:
                print("Invalid choice. Try again.")
        except ValueError:
            print("Please enter a valid number.")


def select_pokemon(available_pokemon=None):
    """
    Let the player select a Pokémon for battle.
    If no available Pokémon are specified, defaults to those that are not fainted.
    """
    # If no available Pokémon are specified, filter out fainted ones
    if available_pokemon is None:
        available_pokemon = [p for p in player_data["pokemon_list"] if p.get("status") != "fainted"]

    # Check if the player has any available Pokémon
    if not available_pokemon:
        print("You have no Pokémon available for battle!")
        return None

    print("Choose your Pokémon for battle:")
    for i, pokemon_entry in enumerate(available_pokemon, 1):
        print(f"{i}. {pokemon_entry['name'].capitalize()} (XP: {pokemon_entry['xp']})")
    
    while True:
        # Get player's choice and validate it
        choice = input("Enter the number of your Pokémon: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(available_pokemon):
            return available_pokemon[int(choice) - 1]
        else:
            print("Invalid choice. Try again.")


def reset_pokemon_status():
    """
    Reset the status of all Pokémon to 'available' after the battle ends.
    """
    for pokemon in player_data["pokemon_list"]:
        pokemon["status"] = "available"


def battle_logic(opponent_pokemon, battle_type, gym_name=None):
    """
    Main battle logic for gym and wild Pokémon battles.
    Handles player and opponent turns, including selecting moves, updating HP, 
    and checking for win/loss conditions.
    """
    if not player_data["pokemon_list"]:
        print("You have no Pokémon to battle with! Catch some Pokémon first.")
        return

    print(f"Prepare for battle!")

    # Player selects their initial Pokémon
    player_pokemon_entry = select_pokemon()
    if not player_pokemon_entry:
        print("No Pokémon selected. Exiting battle.")
        return

    player_pokemon = player_pokemon_entry["name"]

    # Ensure the Pokémon's name is valid in `pokemon_data`
    if player_pokemon not in pokemon_data:
        print(f"Error: {player_pokemon.capitalize()} is not found in Pokémon data!")
        return

    player_hp = pokemon_data[player_pokemon]["HP"]
    opponent_hp = pokemon_data[opponent_pokemon]["HP"]

    while player_hp > 0 and opponent_hp > 0:
        # Player's turn
        print(f"\n{player_pokemon.capitalize()}: {player_hp} HP")
        print(f"{opponent_pokemon.capitalize()}: {opponent_hp} HP")

        move_name, damage = choose_move(player_pokemon)
        print(f"{player_pokemon.capitalize()} used {move_name}! It dealt {damage} damage!")
        opponent_hp -= damage

        if opponent_hp <= 0:  # Opponent fainted
            print(f"{opponent_pokemon.capitalize()} fainted! You win the {battle_type} battle!")
            update_pokemon_xp(player_pokemon, 5)  # XP and evolution logic handled here

            # Award gym badge for gym battles
            if battle_type == "gym" and gym_name:
                badge_name = f"{gym_name} Badge"
                if badge_name not in player_data["gym_badges"]:
                    player_data["gym_badges"].append(badge_name)
                    print(f"Congratulations! You earned the {badge_name}!")
                    save_player_data()
                else:
                    print(f"You already have the {badge_name}.")
            elif battle_type == "wild":
                # Catch wild Pokémon logic
                catch_choice = input(f"Do you want to catch {opponent_pokemon.capitalize()}? (yes/no): ").strip().lower()
                if catch_choice == "yes":
                    if random.randint(1, 100) <= 50:
                        if len(player_data["pokemon_list"]) < 7:
                            player_data["pokemon_list"].append({"name": opponent_pokemon, "xp": 0, "status": "available"})
                            print(f"Congratulations! You caught {opponent_pokemon.capitalize()}!")
                            save_player_data()
                        else:
                            print("Your team is full! Release a Pokémon to make space.")
                    else:
                        print(f"{opponent_pokemon.capitalize()} escaped! Better luck next time.")
            break

        # Opponent's turn
        opp_move = random.choice(pokemon_data[opponent_pokemon]["Moves"])
        opp_move_name, opp_damage = opp_move.split(" (")
        opp_damage = int(opp_damage[:-1])
        print(f"{opponent_pokemon.capitalize()} used {opp_move_name}! It dealt {opp_damage} damage!")
        player_hp -= opp_damage

        if player_hp <= 0:  # Player's Pokémon fainted
            print(f"{player_pokemon.capitalize()} fainted!")
            update_pokemon_xp(player_pokemon, 2)  # XP and evolution logic handled here

            # Mark the Pokémon as fainted
            player_pokemon_entry["status"] = "fainted"

            # Check if player has other Pokémon available
            available_pokemon = [p for p in player_data["pokemon_list"] if p.get("status") != "fainted"]
            if available_pokemon:
                print("Choose another Pokémon to continue the battle!")
                player_pokemon_entry = select_pokemon(available_pokemon)
                if not player_pokemon_entry:
                    print("No Pokémon selected. You lose the battle!")
                    break
                player_pokemon = player_pokemon_entry["name"]
                player_hp = pokemon_data[player_pokemon]["HP"]
            else:
                print("You have no Pokémon left! You lose the battle!")
                break

    # Reset Pokémon status after the battle
    reset_pokemon_status()
    print("All Pokémon have recovered from the battle and are available again!")
