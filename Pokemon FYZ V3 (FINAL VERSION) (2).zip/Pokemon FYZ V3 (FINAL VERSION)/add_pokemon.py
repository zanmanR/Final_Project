from pokemon_list import pokemon_data
from player_database import player_data

def add_to_pokemon_list(pokemon):
    """
    Add a Pokémon to the player's list with initial XP.
    Ensures no duplicate Pokémon are added and enforces the 7 Pokémon limit.
    """
    # Check if the player already has the maximum number of Pokémon
    if len(player_data["pokemon_list"]) >= 7:
        print("Your Pokémon team is full! You must remove a Pokémon before adding a new one.")
        return

    # Check if the Pokémon is already in the player's list
    for p in player_data["pokemon_list"]:
        if p["name"] == pokemon:
            print(f"{pokemon} is already in your Pokémon list!")
            return

    # Add the new Pokémon with initial XP
    player_data["pokemon_list"].append({"name": pokemon, "xp": 0})
    print(f"{pokemon} was added to your Pokémon list!")

def check_evolution(pokemon_entry):
    """
    Check if a Pokémon should evolve based on XP.
    If evolution is available and XP meets the threshold, evolve the Pokémon.
    """
    pokemon_name = pokemon_entry["name"]
    current_xp = pokemon_entry["xp"]

    # Get evolution data
    evolution = pokemon_data.get(pokemon_name, {}).get("Evolution")
    
    # Check if evolution is possible and XP threshold is met (20 XP)
    if evolution and current_xp >= 20:  # Set evolution threshold to 20 XP
        print(f"{pokemon_name.capitalize()} is evolving into {evolution.capitalize()}!")
        pokemon_entry["name"] = evolution  # Update to evolved form
        pokemon_entry["xp"] = 0  # Reset XP after evolution
        return True  # Evolution occurred
    elif not evolution:
        print(f"{pokemon_name.capitalize()} cannot evolve further.")
    
    return False  # No evolution occurred

def update_pokemon_xp(pokemon_name, xp):
    """
    Update XP for a Pokémon and check for evolution.
    """
    # Search for the Pokémon in the player's list
    for pokemon in player_data["pokemon_list"]:
        if pokemon["name"] == pokemon_name:
            pokemon["xp"] += xp
            print(f"{pokemon_name.capitalize()} gained {xp} XP! Total XP: {pokemon['xp']}")

            # Check for evolution and suppress duplicate prints
            if check_evolution(pokemon):
                print(f"Congratulations! {pokemon_name.capitalize()} has evolved!")
            return
    
    # Pokémon not found in the player's list
    print(f"{pokemon_name.capitalize()} is not in your team.")
