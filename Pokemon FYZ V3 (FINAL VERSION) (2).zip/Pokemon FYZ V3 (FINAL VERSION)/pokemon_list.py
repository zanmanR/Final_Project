pokemon_data = {
    "bulbasaur": {"HP": 75, "Moves": ["Tackle (40)", "Growl (20)"], "Evolution": "ivysaur"},
    "ivysaur": {"HP": 115, "Moves": ["Vine Whip (45)", "Growl (20)"], "Evolution": "venusaur"},
    "venusaur": {"HP": 165, "Moves": ["Razor Leaf (55)", "SolarBeam (120)"], "Evolution": None},
    
    "charmander": {"HP": 75, "Moves": ["Scratch (40)", "Growl (40)"], "Evolution": "charmeleon"},
    "charmeleon": {"HP": 115, "Moves": ["Ember (40)", "Leer (60)"], "Evolution": "charizard"},
    "charizard": {"HP": 165, "Moves": ["Flamethrower (95)", "Fly (90)"], "Evolution": None},
    
    "squirtle": {"HP": 75, "Moves": ["Tackle (40)", "Tail Whip (0)"], "Evolution": "wartortle"},
    "wartortle": {"HP": 115, "Moves": ["Water Gun (40)", "Bite (60)"], "Evolution": "blastoise"},
    "blastoise": {"HP": 165, "Moves": ["Hydro Pump (110)", "Ice Beam (95)"], "Evolution": None},
    
    "caterpie": {"HP": 55, "Moves": ["Tackle (40)", "String Shot (0)"], "Evolution": "metapod"},
    "metapod": {"HP": 85, "Moves": ["Harden (0)"], "Evolution": "butterfree"},
    "butterfree": {"HP": 135, "Moves": ["Confusion (50)", "Sleep Powder (0)"], "Evolution": None},
    
    "weedle": {"HP": 55, "Moves": ["Poison Sting (15)", "String Shot (0)"], "Evolution": "kakuna"},
    "kakuna": {"HP": 85, "Moves": ["Harden (0)"], "Evolution": "beedrill"},
    "beedrill": {"HP": 135, "Moves": ["Twinneedle (25)", "Poison Jab (80)"], "Evolution": None},
    
    "pidgey": {"HP": 65, "Moves": ["Tackle (40)", "Gust (40)"], "Evolution": "pidgeotto"},
    "pidgeotto": {"HP": 105, "Moves": ["Quick Attack (40)", "Gust (40)"], "Evolution": "pidgeot"},
    "pidgeot": {"HP": 155, "Moves": ["Hurricane (110)", "Air Slash (75)"], "Evolution": None},
    
    "rattata": {"HP": 65, "Moves": ["Tackle (40)", "Quick Attack (40)"], "Evolution": "raticate"},
    "raticate": {"HP": 105, "Moves": ["Hyper Fang (80)", "Bite (60)"], "Evolution": None},
    
    "ekans": {"HP": 65, "Moves": ["Wrap (20)", "Leer (0)"], "Evolution": "arbok"},
    "arbok": {"HP": 105, "Moves": ["Poison Sting (15)", "Acid (40)"], "Evolution": None},
    
    "pikachu": {"HP": 85, "Moves": ["Thunderbolt (90)", "Quick Attack (40)"], "Evolution": "raichu"},
    "raichu": {"HP": 135, "Moves": ["Thunder (110)", "Quick Attack (40)"], "Evolution": None},
    
    "sandshrew": {"HP": 75, "Moves": ["Scratch (40)", "Defense Curl (0)"], "Evolution": "sandslash"},
    "sandslash": {"HP": 115, "Moves": ["Slash (70)", "Earthquake (100)"], "Evolution": None},
    
    "nidoran♀": {"HP": 65, "Moves": ["Scratch (40)", "Growl (0)"], "Evolution": "nidorina"},
    "nidorina": {"HP": 105, "Moves": ["Double Kick (60)", "Bite (60)"], "Evolution": "nidoqueen"},
    "nidoqueen": {"HP": 155, "Moves": ["Earthquake (100)", "Body Slam (85)"], "Evolution": None},
    
    "nidoran♂": {"HP": 65, "Moves": ["Tackle (40)", "Leer (30)"], "Evolution": "nidorino"},
    "nidorino": {"HP": 105, "Moves": ["Poison Sting (15)", "Double Kick (60)"], "Evolution": "nidoking"},
    "nidoking": {"HP": 155, "Moves": ["Earthquake (100)", "Megahorn (120)"], "Evolution": None},
    
    "clefairy": {"HP": 95, "Moves": ["Pound (40)", "Sing (20)"], "Evolution": "clefable"},
    "clefable": {"HP": 145, "Moves": ["Moonblast (95)", "Dazzling Gleam (80)"], "Evolution": None},
    
    "vulpix": {"HP": 65, "Moves": ["Quick Attack (40)", "Ember (40)"], "Evolution": "ninetales"},
    "ninetales": {"HP": 115, "Moves": ["Flamethrower (95)", "Quick Attack (40)"], "Evolution": None},
    
    "jigglypuff": {"HP": 105, "Moves": ["Pound (40)", "Sing (20)"], "Evolution": "wigglytuff"},
    "wigglytuff": {"HP": 155, "Moves": ["Hyper Voice (90)", "Dazzling Gleam (80)"], "Evolution": None},
    
    "zubat": {"HP": 55, "Moves": ["Leech Life (20)", "Supersonic (40)"], "Evolution": "golbat"},
    "golbat": {"HP": 105, "Moves": ["Bite (60)", "Air Cutter (60)"], "Evolution": None},

    "oddish": {"HP": 75, "Moves": ["Absorb (20)", "Poison Powder (30)"], "Evolution": "gloom"},
    "gloom": {"HP": 115, "Moves": ["Acid (40)", "Stun Spore (40)"], "Evolution": "vileplume"},
    "vileplume": {"HP": 165, "Moves": ["SolarBeam (120)", "Petal Dance (80)"], "Evolution": None},
    
    "paras": {"HP": 65, "Moves": ["Scratch (40)", "Stun Spore (10)"], "Evolution": "parasect"},
    "parasect": {"HP": 105, "Moves": ["Spore (20)", "Cut (50)"], "Evolution": None},
    
    "venonat": {"HP": 75, "Moves": ["Tackle (40)", "Poison Powder (30)"], "Evolution": "venomoth"},
    "venomoth": {"HP": 115, "Moves": ["Bug Buzz (90)", "Confusion (50)"], "Evolution": None},
    
    "diglett": {"HP": 55, "Moves": ["Scratch (40)", "Dig (80)"], "Evolution": "dugtrio"},
    "dugtrio": {"HP": 105, "Moves": ["Earthquake (100)", "Sand Attack (25)"], "Evolution": None},
    
    "meowth": {"HP": 65, "Moves": ["Scratch (40)", "bite (30)"], "Evolution": "persian"},
    "persian": {"HP": 115, "Moves": ["Pay Day (40)", "Slash (70)"], "Evolution": None},
    
    "psyduck": {"HP": 75, "Moves": ["Scratch (40)", "Confusion (50)"], "Evolution": "golduck"},
    "golduck": {"HP": 115, "Moves": ["Hydro Pump (110)", "Psychic (90)"], "Evolution": None},
    
    "mankey": {"HP": 65, "Moves": ["Low Kick (50)", "Scratch (40)"], "Evolution": "primeape"},
    "primeape": {"HP": 105, "Moves": ["Cross Chop (100)", "Karate Chop (50)"], "Evolution": None},
    
    "growlithe": {"HP": 75, "Moves": ["Bite (60)", "Roar (20)"], "Evolution": "arcanine"},
    "arcanine": {"HP": 115, "Moves": ["Flamethrower (95)", "Extreme Speed (80)"], "Evolution": None},
    
    "poliwag": {"HP": 75, "Moves": ["Bubble (40)", "Hypnosis (30)"], "Evolution": "poliwhirl"},
    "poliwhirl": {"HP": 115, "Moves": ["Water Gun (40)", "Double Slap (35)"], "Evolution": "poliwrath"},
    "poliwrath": {"HP": 165, "Moves": ["Hydro Pump (110)", "Submission (80)"], "Evolution": None},
    
    "abra": {"HP": 45, "Moves": ["psybeam (40)", "Confusion (30)"], "Evolution": "kadabra"},
    "kadabra": {"HP": 95, "Moves": ["Psychic (90)", "Kinesis (50)"], "Evolution": "alakazam"},
    "alakazam": {"HP": 145, "Moves": ["Psychic (90)", "Focus Blast (120)"], "Evolution": None},
    
    "machop": {"HP": 75, "Moves": ["Low Kick (50)", "Focus Energy (40)"], "Evolution": "machoke"},
    "machoke": {"HP": 115, "Moves": ["Karate Chop (50)", "Submission (80)"], "Evolution": "machamp"},
    "machamp": {"HP": 165, "Moves": ["Dynamic Punch (100)", "Close Combat (100)"], "Evolution": None},
    
    "bellsprout": {"HP": 55, "Moves": ["Vine Whip (45)", "Acid (40)"], "Evolution": "weepinbell"},
    "weepinbell": {"HP": 95, "Moves": ["Slam (50)", "Acid (40)"], "Evolution": "victreebel"},
    "victreebel": {"HP": 145, "Moves": ["SolarBeam (120)", "Swords Dance (40)"], "Evolution": None},
    
    "tentacool": {"HP": 75, "Moves": ["Acid (40)", "Constrict (10)"], "Evolution": "tentacruel"},
    "tentacruel": {"HP": 115, "Moves": ["Surf (95)", "Toxic Spikes (30)"], "Evolution": None},
    
    "geodude": {"HP": 75, "Moves": ["Tackle (40)", "Rock Throw (50)"], "Evolution": "graveler"},
    "graveler": {"HP": 115, "Moves": ["Rock Slide (75)", "Earthquake (100)"], "Evolution": "golem"},
    "golem": {"HP": 165, "Moves": ["Earthquake (100)", "Stone Edge (100)"], "Evolution": None},
    
    "ponyta": {"HP": 75, "Moves": ["Tackle (40)", "Double Kick (40)"], "Evolution": "rapidash"},
    "rapidash": {"HP": 115, "Moves": ["Flamethrower (95)", "Bounce (85)"], "Evolution": None},
    
    "slowpoke": {"HP": 95, "Moves": ["Tackle (40)", "Confusion (50)"], "Evolution": "slowbro"},
    "slowbro": {"HP": 145, "Moves": ["Surf (95)", "Psychic (90)"], "Evolution": None},
    
    "magnemite": {"HP": 65, "Moves": ["Tackle (40)", "Thunder Wave (40)"], "Evolution": "magneton"},
    "magneton": {"HP": 115, "Moves": ["Thunderbolt (90)", "Magnet Bomb (60)"], "Evolution": None},
    
    "farfetch'd": {"HP": 75, "Moves": ["Peck (35)", "Swords Dance (50)"], "Evolution": None},
    
    "doduo": {"HP": 65, "Moves": ["Peck (35)", "bite (30)"], "Evolution": "dodrio"},
    "dodrio": {"HP": 105, "Moves": ["Drill Peck (80)", "Agility (20)"], "Evolution": None},
    
    "seel": {"HP": 75, "Moves": ["Headbutt (35)", "scratch (25)"], "Evolution": "dewgong"},
    "dewgong": {"HP": 105, "Moves": ["Ice Beam (70)", "Aqua Tail (80)"], "Evolution": None},
    
    "grimer": {"HP": 85, "Moves": ["Pound (40)", "Disable (20)"], "Evolution": "muk"},
    "muk": {"HP": 135, "Moves": ["Sludge Bomb (90)", "Toxic (30)"], "Evolution": None},
    
    "shellder": {"HP": 55, "Moves": ["Tackle (40)", "water blast (40)"], "Evolution": "cloyster"},
    "cloyster": {"HP": 105, "Moves": ["Icicle Spear (25)", "Hydro Pump (110)"], "Evolution": None},
    
    "gastly": {"HP": 45, "Moves": ["Lick (30)", "Night Shade (50)"], "Evolution": "haunter"},
    "haunter": {"HP": 95, "Moves": ["Shadow Ball (80)", "Confuse Ray (50)"], "Evolution": "gengar"},
    "gengar": {"HP": 145, "Moves": ["Shadow Ball (80)", "Sludge Bomb (90)"], "Evolution": None},

    "rhyhorn": {"HP": 85, "Moves": ["Tackle (40)", "Horn Attack (65)"], "Evolution": "rhydon"},
    "rhydon": {"HP": 135, "Moves": ["Earthquake (100)", "Rock Slide (75)"], "Evolution": None},
    
    "chansey": {"HP": 255, "Moves": ["Soft-Boiled (40)", "Egg Bomb (60)"], "Evolution": "blissey"},
    "blissey": {"HP": 305, "Moves": ["Soft-Boiled (40)", "Seismic Toss (60)"], "Evolution": None},
    
    "tangela": {"HP": 75, "Moves": ["Vine Whip (45)", "Constrict (10)"], "Evolution": "tangrowth"},
    "tangrowth": {"HP": 125, "Moves": ["Power Whip (120)", "Slam (50)"], "Evolution": None},
    
    "electrode": {"HP": 95, "Moves": ["Thunderbolt (90)", "Self-Destruct (200)"], "Evolution": None},
    
    "exeggutor": {"HP": 125, "Moves": ["SolarBeam (120)", "Psychic (90)"], "Evolution": None},
    
    "pinsir": {"HP": 85, "Moves": ["Vice Grip (55)", "X-Scissor (80)"], "Evolution": None},
    
    "magikarp": {"HP": 65, "Moves": ["Splash (0)", "Tackle (40)"], "Evolution": "gyarados"},
    "gyarados": {"HP": 115, "Moves": ["Hydro Pump (110)", "Bite (60)"], "Evolution": None},
    
    "lapras": {"HP": 125, "Moves": ["Surf (95)", "Ice Beam (95)"], "Evolution": None},
    
    "ditto": {"HP": 60, "Moves": ["pound (10)", "Struggle (30)"], "Evolution": None},
    
    "eevee": {"HP": 55, "Moves": ["Tackle (40)", "bite (30)"], "Evolution": ["vaporeon", "jolteon", "flareon"]},
    "vaporeon": {"HP": 105, "Moves": ["Water Gun (40)", "Aqua Tail (90)"], "Evolution": None},
    "jolteon": {"HP": 105, "Moves": ["Thunderbolt (90)", "Thunder (110)"], "Evolution": None},
    "flareon": {"HP": 105, "Moves": ["Flamethrower (95)", "Fire Blast (80)"], "Evolution": None},
    
    "porygon": {"HP": 65, "Moves": ["Psybeam (65)", "bite (30)"], "Evolution": "porygon2"},

    "omanyte": {"HP": 75, "Moves": ["Water Gun (40)", "Rock Throw (50)"], "Evolution": "omastar"},
    "omastar": {"HP": 125, "Moves": ["Hydro Pump (110)", "Ancient Power (60)"], "Evolution": None},
    
    "kabuto": {"HP": 70, "Moves": ["Scratch (40)", "Absorb (20)"], "Evolution": "kabutops"},
    "kabutops": {"HP": 115, "Moves": ["Slash (70)", "Rock Slide (75)"], "Evolution": None},
    
    "aerodactyl": {"HP": 90, "Moves": ["Wing Attack (60)", "Hyper Beam (150)"], "Evolution": None},
    
    "snorlax": {"HP": 210, "Moves": ["Body Slam (85)", "crunch (40)"], "Evolution": None},
    
    "articuno": {"HP": 130, "Moves": ["Ice Beam (95)", "Blizzard (110)"], "Evolution": None},
    "zapdos": {"HP": 130, "Moves": ["Thunderbolt (90)", "Drill Peck (80)"], "Evolution": None},
    "moltres": {"HP": 130, "Moves": ["Flamethrower (95)", "Fire Blast (110)"], "Evolution": None},
    
    "dratini": {"HP": 61, "Moves": ["Wrap (15)", "Dragon Rage (40)"], "Evolution": "dragonair"},
    "dragonair": {"HP": 91, "Moves": ["Dragon Pulse (85)", "Thunder Wave (50)"], "Evolution": "dragonite"},
    "dragonite": {"HP": 151, "Moves": ["Outrage (120)", "Hurricane (110)"], "Evolution": None},
    
    "mewtwo": {"HP": 154, "Moves": ["Psychic (90)", "Shadow Ball (80)"], "Evolution": None},
    "mew": {"HP": 110, "Moves": ["Psychic (90)", "ice beam (60)"], "Evolution": None},
    "ho-oh": {"HP": 1500, "Moves": ["Sacred Fire (150)", "Ancient Power (100)"], "Evolution": None},


    "shayan": {"HP": 200000000000000, "Moves": ["stupid (40)", "little stupid (15)"], "Evolution": "yousuf"},
    "yousuf": {"HP": 12, "Moves": ["really stupid (85)", "super stupid (90)"], "Evolution": "faizan"},
    "faizan": {"HP": 69000, "Moves": ["sigma (12 million)", "super sigma (110 million)"], "Evolution": None},
}













