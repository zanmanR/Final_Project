from pokedex import view_pokedex
from battle import battle_logic
from map import explore_map
from player_database import player_data  # Import the centralized player database

def view_player_pokemon():
    """
    Display the player's Pokémon team with their XP.
    
    If the player has no Pokémon, a message is displayed prompting them to capture some.
    """
    print("\nYour Pokémon:")
    # Check if the player has any Pokémon in their team
    if not player_data["pokemon_list"]:
        print("You have no Pokémon yet! Go capture some!")
    else:
        # Display each Pokémon's name and XP
        for i, pokemon_entry in enumerate(player_data["pokemon_list"], 1):
            name = pokemon_entry["name"].capitalize()
            xp = pokemon_entry["xp"]
            print(f"{i}. {name} (XP: {xp})")

def view_gym_badges():
    """
    Display the player's earned gym badges.
    
    If the player has no badges, a message is displayed informing them of that.
    """
    print("\nGym Badges:")
    # Check if the player has earned any gym badges
    if not player_data["gym_badges"]:
        print("You don't have any gym badges yet!")
    else:
        # Display each earned gym badge
        for badge in player_data["gym_badges"]:
            print(f"- {badge}")

def display_menu():
    """
    Display the main menu, allowing the player to access the Pokédex,
    view their Pokémon team, explore the map, or check gym badges.
    
    The player can choose options by entering corresponding numbers.
    """
    while True:
        # Display the menu options
        print("\nMenu:")
        print("1. View Pokédex")
        print("2. View Your Pokémon")
        print("3. Explore Map")
        print("4. View Gym Badges")
        print("5. Quit Menu")

        # Prompt the player to choose an option
        choice = input("Choose an option (1/2/3/4/5): ").strip()

        # Execute corresponding actions based on player's choice
        if choice == "1":
            view_pokedex()
        elif choice == "2":
            view_player_pokemon()
        elif choice == "3":
            explore_map()
        elif choice == "4":
            view_gym_badges()
        elif choice == "5":
            print("Exiting the menu...")
            break
        else:
            print("Invalid choice. Try again.")
