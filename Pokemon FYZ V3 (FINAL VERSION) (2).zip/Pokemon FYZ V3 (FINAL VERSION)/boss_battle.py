from battle import battle_logic
from player_database import player_data


def boss_battle():
    """
    Trigger the final Boss Battle when the player reaches the Boss Battle location.
    """
    print("\nYou have entered Mount Tensei!")
    print("Prepare to face the ultimate challenge!")

    # List of boss Pokémon for the battle
    boss_pokemon_list = ["ho-oh"]

    # Loop through each boss Pokémon and trigger the battle
    for boss_pokemon in boss_pokemon_list:
        print(f"\nThe boss sends out {boss_pokemon.capitalize()}!")
        battle_logic(boss_pokemon, "boss")

        # Check if the player still has Pokémon left after the battle
        if not any(pokemon for pokemon in player_data["pokemon_list"] if pokemon["xp"] > 0):
            print("\nYou have no Pokémon left to fight! You lost the Boss Battle!")
            return

    # If the player has won all battles
    print("\nCongratulations! You have defeated the boss and become the Pokémon Champion!")
