from pokemon_list import pokemon_data
from add_pokemon import add_to_pokemon_list


def choose_starter():
    """
    Let the player choose a starter Pokémon and return the chosen Pokémon.
    """
    print("Choose your starter Pokémon:")
    
    # List of available starter Pokémon
    starters = ["bulbasaur", "charmander", "squirtle"]  # Lowercase to match `pokemon_data` keys

    # Display the available starters
    for i, starter in enumerate(starters, 1):
        print(f"{i}. {starter.capitalize()}")  # Display capitalized names for better readability

    while True:
        # Prompt the user to select a starter
        choice = input("Enter the number of your choice: ").strip()
        if choice in ["1", "2", "3"]:
            # Return the chosen starter Pokémon
            starter = starters[int(choice) - 1]
            print(f"You chose {starter.capitalize()}!")
            return starter
        else:
            # Handle invalid input
            print("Invalid choice. Try again.")


def tutorial(starter):
    """
    Provides a basic tutorial introduction for the player based on their starter Pokémon.
    """
    # Introduction to the game and the player's chosen starter
    print(f"\nWelcome to the world of Pokémon! You start your journey with {starter.capitalize()}.")
    print("Explore the map, battle wild Pokémon, and become a Pokémon Master!")
