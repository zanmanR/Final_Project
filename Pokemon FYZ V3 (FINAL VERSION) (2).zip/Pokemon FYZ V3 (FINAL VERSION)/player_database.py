import json

# Player data file location
file_name = "player_data.txt"

# Player database: includes player's Pokémon and other information
player_data = {
    "name": "",  # Starts as blank, updated when the player provides a name
    "pokemon_list": [],  # List of Pokémon owned by the player
    "gym_badges": []  # List of gym badges
}


def add_pokemon_to_player(pokemon):
    """
    Add a Pokémon to the player's database, ensuring a max of 7 Pokémon.
    
    """
    # Ensure the player has less than 7 Pokémon
    if len(player_data["pokemon_list"]) < 7:
        player_data["pokemon_list"].append({"name": pokemon, "xp": 0})  # Save Pokémon with XP
        print(f"{pokemon.capitalize()} has been added to your team!")
    else:
        print("You already have 7 Pokémon. You can't carry more!")


def remove_pokemon_from_player(pokemon_name):
    """
    Remove a Pokémon from the player's database.
    
    """
    # Search for the Pokémon in the player's team and remove it
    for pokemon in player_data["pokemon_list"]:
        if pokemon["name"] == pokemon_name:
            player_data["pokemon_list"].remove(pokemon)
            print(f"{pokemon_name.capitalize()} has been removed from your team.")
            return
    print(f"{pokemon_name.capitalize()} is not in your team.")


def save_player_data():
    """
    Save the player's data to a file.
    """
    # Write the player data to the player data file
    with open(file_name, "w") as file:
        json.dump(player_data, file)
    print(f"Player data saved to {file_name}.")


def load_player_data():
    """
    Load the player's data from a file.
    """
    global player_data
    try:
        # Attempt to open and read the file
        print(f"Attempting to load player data from {file_name}...")
        with open(file_name, "r") as file:
            loaded_data = json.load(file)  # Load JSON from file
            
            # Ensure the loaded data is valid and contains the required keys
            if isinstance(loaded_data, dict):
                required_keys = {"name", "pokemon_list", "gym_badges"}
                if required_keys.issubset(loaded_data.keys()):
                    player_data.update(loaded_data)
                    print("Player data loaded successfully!")
                else:
                    print("Error: Loaded data is missing required keys. Starting fresh.")
            else:
                print(f"Error: The data in {file_name} is not a valid dictionary. Starting fresh.")
    except FileNotFoundError:
        print(f"File {file_name} not found. No data to load. Starting fresh.")
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON in {file_name}: {e}. Starting fresh.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}. Starting fresh.")




def display_player_data():
    """
    Display the player's current Pokémon and badges.
    """
    print("\nPlayer Data:")
    # Display player's name or prompt for name if not set
    print(f"Name: {player_data['name'] if player_data['name'] else 'No name set'}")
    
    print("Pokémon Team:")
    # Display all Pokémon in the player's team or show a message if no Pokémon are owned
    if player_data["pokemon_list"]:
        for i, pokemon in enumerate(player_data["pokemon_list"], 1):
            print(f"{i}. {pokemon['name'].capitalize()} (XP: {pokemon['xp']})")
    else:
        print("No Pokémon in the team.")
    
    print("Gym Badges:")
    # Display the gym badges or show a message if none are earned yet
    if player_data["gym_badges"]:
        for badge in player_data["gym_badges"]:
            print(f"- {badge}")
    else:
        print("No gym badges yet.")


def set_player_name():
    """
    Set the player's name if it's currently blank.
    """
    if not player_data["name"]:
        # Prompt the player to enter their name if not already set
        name = input("Enter your name, Trainer: ").strip()
        player_data["name"] = name
        print(f"Welcome, {name}! Let's begin your adventure!")
    else:
        print(f"Your name is already set as {player_data['name']}.")
