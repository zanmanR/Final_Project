from gym import fight_gym_trainer
from wild_pokemon import explore_location
from player_database import player_data
from boss_battle import boss_battle

# Initial map layout (before unlocking Boss Battle location)
map_layout = [
    ["Pallet Town", "Viridian Forest", "Celadon City"],
    ["Victory Road", "Lavender Town", "Rock Tunnel"],
    ["Cerulean City", "Seafoam Islands", "Mt. Moon"]
]

# Expanded map layout with the Boss Battle location unlocked
expanded_map_layout = [
    ["Pallet Town", "Viridian Forest", "Celadon City"],
    ["Victory Road", "Lavender Town", "Rock Tunnel"],
    ["Cerulean City", "Seafoam Islands", "Mt. Moon"],
    ["Mount Tensei"]
]

# Starting position of the player at "Pallet Town"
player_position = [0, 0]

def display_map():
    """
    Display the current map with the player's position highlighted.
    """
    print("\nMap:")
    for i, row in enumerate(map_layout):
        row_display = []
        for j, location in enumerate(row):
            # Highlight the player's current location
            if [i, j] == player_position:
                row_display.append(f"[{location}]")
            else:
                row_display.append(location)
        print(" | ".join(row_display))

def move_player(direction):
    """
    Move the player on the map based on the direction.
    
    Parameters:
    direction (str): The direction to move the player ("up", "down", "left", "right").
    """
    global player_position
    i, j = player_position

    # Determine map dimensions based on the current layout
    max_row = len(map_layout) - 1
    max_col = len(map_layout[0]) - 1 if len(map_layout) > i else 0

    # Update position based on direction
    if direction == "up" and i > 0:
        player_position[0] -= 1
    elif direction == "down" and i < max_row:
        player_position[0] += 1
    elif direction == "left" and j > 0:
        player_position[1] -= 1
    elif direction == "right" and j < max_col:
        player_position[1] += 1
    else:
        print("You can't move in that direction.")

def update_map():
    """
    Update the map layout if the player collects all 4 gym badges.
    Unlocks the Boss Battle location.
    """
    global map_layout
    # Check if the player has 4 gym badges and update the map
    if len(player_data["gym_badges"]) == 4 and map_layout != expanded_map_layout:
        map_layout = expanded_map_layout
        print("\nThe map has been updated! A new location, 'Boss Battle,' has been unlocked!")

def explore_map():
    """
    Allow the player to explore the map, challenge gym trainers, or encounter wild Pokémon.
    """
    while True:
        update_map()  # Check if the map needs to be updated
        display_map()  # Display the current map

        # Get the player's current location
        current_location = map_layout[player_position[0]][player_position[1]]
        print(f"\nYou are now in {current_location}.")

        # Handle different locations and actions
        if current_location == "Mount Tensei":
            boss_battle()  # Trigger the boss battle when at the location
            break
        elif current_location in ["Pallet Town", "Celadon City", "Lavender Town", "Cerulean City"]:
            # Gym locations
            action = input("Do you want to fight the gym trainer, move, or quit? (gym/move/quit): ").strip().lower()
            if action == "gym":
                fight_gym_trainer(current_location)  # Fight the gym trainer
            elif action == "move":
                direction = input("Which direction do you want to move? (up/down/left/right): ").strip().lower()
                move_player(direction)  # Move the player in the specified direction
            elif action == "quit":
                break
            else:
                print("Invalid input. Try again.")
        else:
            # Non-gym locations (wild Pokémon encounters)
            action = input("Do you want to explore, fight, move, or quit? (explore/fight/move/quit): ").strip().lower()
            if action in ["explore", "fight"]:
                explore_location(current_location, action)  # Explore or fight wild Pokémon
            elif action == "move":
                direction = input("Which direction do you want to move? (up/down/left/right): ").strip().lower()
                move_player(direction)  # Move the player
            elif action == "quit":
                break
            else:
                print("Invalid input. Try again.")

def get_current_location():
    """
    Return the current location of the player.
    
    Returns:
    str: The name of the current location where the player is.
    """
    return map_layout[player_position[0]][player_position[1]]
