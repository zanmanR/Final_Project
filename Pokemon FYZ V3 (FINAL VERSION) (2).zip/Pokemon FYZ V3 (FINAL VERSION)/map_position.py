
# Initial map layout (before unlocking Boss Battle location)
map_layout = [
    ["Pallet Town", "Viridian Forest", "Celadon City"],
    ["Victory Road", "Lavender Town", "Rock Tunnel"],
    ["Cerulean City", "Seafoam Islands", "Mt. Moon"],
]

# New map layout with the Boss Battle location added
expanded_map_layout = [
    ["Pallet Town", "Viridian Forest", "Celadon City"],
    ["Victory Road", "Lavender Town", "Rock Tunnel"],
    ["Cerulean City", "Seafoam Islands", "Mt. Moon"],
    ["Boss Battle"]
]

# Initialize player position at the starting point "Pallet Town"
player_position = [0, 0]  # Starting position at "Pallet Town"

# Get the player's current location
current_location = map_layout[player_position[0]][player_position[1]]

def get_current_location():
    """
    Return the player's current location on the map.
    
    Returns:
        str: The name of the current location on the map.
    """
    return map_layout[player_position[0]][player_position[1]]

def move_player(direction):
    """
    Move the player on the map based on the direction.
    Valid directions: 'up', 'down', 'left', 'right'.
    
    """
    global player_position

    # Determine map dimensions based on the current layout
    max_row = len(map_layout) - 1
    max_col = len(map_layout[0]) - 1 if len(map_layout) > player_position[0] else 0

    # Update position based on the direction
    if direction == "up" and player_position[0] > 0:
        player_position[0] -= 1
    elif direction == "down" and player_position[0] < max_row:
        player_position[0] += 1
    elif direction == "left" and player_position[1] > 0:
        player_position[1] -= 1
    elif direction == "right" and player_position[1] < max_col:
        player_position[1] += 1
    else:
        print("You can't move in that direction!")

    # Display the updated location after moving
    print(f"You moved to {get_current_location()}.")

def update_map():
    """
    Update the map layout if all 4 gym badges are collected.
    
    The map will be updated to unlock the "Boss Battle" location.
    """
    global map_layout
    from player_database import player_data  # Import player data to check badges

    # Check if the player has collected all gym badges
    if len(player_data["gym_badges"]) == 4:
        map_layout = expanded_map_layout  # Unlock the Boss Battle location
        print("\nThe map has been updated! A new location, 'Boss Battle,' has been unlocked!")
    else:
        print("\nKeep collecting gym badges to unlock the new area.")

def display_map():
    """
    Display the current map with the player's position highlighted.
    
    The player's location is shown in square brackets.
    """
    print("\nMap:")
    for row_idx, row in enumerate(map_layout):
        row_display = []
        for col_idx, location in enumerate(row):
            # Highlight the player's current location with square brackets
            if [row_idx, col_idx] == player_position:
                row_display.append(f"[{location}]")
            else:
                row_display.append(location)
        print(" | ".join(row_display))
